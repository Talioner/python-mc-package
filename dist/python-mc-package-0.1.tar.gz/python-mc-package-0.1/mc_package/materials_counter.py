def count_tiles(x, y, s):
    result = float(x) * float(y) / float(s)
    return result


def count_time(s, v):
    time = float(s) / float(v)
    return time
